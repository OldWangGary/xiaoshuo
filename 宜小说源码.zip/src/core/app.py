from src.core import download_manager
import signal
from src.units import unitl
from concurrent.futures import ThreadPoolExecutor
from src.units.logger import logger
from src.core import downloading

stop_page = False

def init(url):
    signal.signal(signal.SIGINT,stop_thread)
    add_urls(url)
    download_content()
    save_content()


def add_urls(url,page=1):
    while not stop_page:
        download_manager.add_section_list(url,page=page)
        url = download_manager.page_list[len(download_manager.page_list)-1]['page_url']
        page = download_manager.page_list[len(download_manager.page_list)-1]['page_num']


def download_content():
    global ex
    download_content_list = unitl.sorted_list(download_manager.section_list)
    with ThreadPoolExecutor(max_workers=32) as ex:
        for d in download_content_list:
            ex.submit(download_manager.content_manager,d['num'],d['u']).add_done_callback(worker_callback)

def save_content():
    file_type = 'txt'
    downloading.writer(download_manager.title + '.'+ file_type)

def worker_callback(worker):
    exception = worker.exception()
    if exception:
        logger.exception(exception)

def stop_thread(sign,frame):
    global stop_page
    stop_page = True
    if ex:
        ex.shutdown(cancel_futures=True)
    logger.info('中断下载')