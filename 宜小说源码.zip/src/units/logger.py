from loguru import logger
from pathlib import Path
from src.units import unitl

log_dir = 'log'
levelinfo = 'INFO'
leveldebug = 'DEBUG'

logger.add(Path(log_dir).joinpath(f"{unitl.str_time()}.log"),rotation="10MB", encoding="utf-8", enqueue=True, retention="10 days",level=levelinfo)