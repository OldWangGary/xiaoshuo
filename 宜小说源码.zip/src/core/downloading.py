from src.units import unitl

conetent_list = []

def writer(title):
    global conetent_list
    conetent_list = unitl.sorted_list(conetent_list,k=True)
    with open(title,'w',encoding='utf8') as f:
        for i,c in conetent_list:
            f.write('\n'.join(c))