import time

def sorted_list(l,k=False):
    if k:
        return sorted(l,reverse=False,key=lambda l:l[0])
    else:
        return sorted(l,key= lambda l:l.get('num'),reverse=False)

def str_time():
    now = time.localtime()
    return time.strftime('%Y%m%d_%H%M%S',now)