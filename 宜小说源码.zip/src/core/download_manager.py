import requests
from lxml import etree
from src.core import app
import re
from src.core import downloading
from src.units.logger import logger


base_url = 'https://m.moyisy.com'
section_list = []
page_list = []
title = ''
i = 0


def add_section_list(url,page=1):
    global i,title
    logger.info(f'正在爬取第{page}页')
    res = requests.get(url).text
    html = etree.HTML(res, parser=None)
    title = html.xpath('//h1/text()')[0]
    hrefs = html.xpath(
        f'//h2[text()="《{title}》正文"]/following-sibling::div[@class="section-box"]/ul/li/a/@href')
    for h in hrefs:
        i += 1
        section_list.append({"num": i, "u": base_url+h})
        i += 1
        _h = h.rsplit("/", 1)[0] + '/' + h.rsplit("/", 1)[-1][:-5] + "_2.html"
        section_list.append({"num": i, "u": base_url+_h})
    get_next_page(html)




def get_next_page(html):
    next_page_num = html.xpath('//a[text()="下一页"]/@href')
    if next_page_num:
        page_num = re.findall(r'\d+', next_page_num[0].rsplit('/', 1)[-1])[0]
        page_list.append({'page_num': int(page_num),
                         'page_url': base_url + next_page_num[0]})
    else:
        app.stop_page = True


def content_manager(index, url):
    res = requests.get(url).text
    html = etree.HTML(res, parser=None)
    _title = html.xpath('//h1[@class="title"]/text()')
    content = html.xpath('//div[@class="content"]/text()')
    content = [i.replace('\u3000', ' ') for i in content]
    if "_2.html" in url:
        downloading.conetent_list.append([index, content])
    else:
        downloading.conetent_list.append([index, _title+content])
    logger.info(f'正在保存{_title[0]}')
